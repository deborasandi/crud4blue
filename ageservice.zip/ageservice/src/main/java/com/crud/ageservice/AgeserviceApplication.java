package com.crud.ageservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgeserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgeserviceApplication.class, args);
	}

}

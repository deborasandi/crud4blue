package com.crud.personservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
